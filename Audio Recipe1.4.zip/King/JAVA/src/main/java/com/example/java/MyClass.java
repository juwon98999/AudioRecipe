package com.example.java;

public class MyClass {
}